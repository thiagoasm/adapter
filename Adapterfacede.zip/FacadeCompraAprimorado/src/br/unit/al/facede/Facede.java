package br.unit.al.facede;

import br.unit.al.bo.CarrinhoBO;
import br.unit.al.bo.ClienteBO;
import br.unit.al.bo.ProdutoBO;
import br.unit.al.dao.BancoDeDados;


public class Facede {
	
	ClienteBO clienteBo;
	CarrinhoBO carrinhoBo=null;
	BancoDeDados bd;
	ProdutoBO produtoBo =null;
	
	
	public void registrarCliente(String nome, int cpf,String endereco, int id) {
		bd.conectar();

		clienteBo=ClienteBO.create(nome, cpf, endereco,id);	
		bd.inserirCliente(nome, cpf, endereco, id);
		carrinhoBo= carrinhoBo.create();
		clienteBo.adicionarCarinho(carrinhoBo);
	bd.desconectar();
	
		
	}
	public void comprar (int idCliente, int idProduto){
		bd.conectar();
     //clienteBo=bd.buscaCliente(idCliente);
	//	System.out.println("cliente id: "+clienteBo.getId());
		produtoBo=bd.selectProduto(idProduto);
		//System.out.println("produto: "+ produtoBo.getPreco());
		//System.out.println(clienteBo.getCarrinho().getTotal());
		clienteBo.getCarrinho().adicionar(produtoBo);
		//System.out.println("s"+clienteBo.getCarrinho().getTotal());
		bd.desconectar();
		
	}
	public void fecharCompra(int idCliente) {
		
		bd.conectar();
	
		//clienteBo=bd.buscaCliente(idCliente);
		
		double valor= clienteBo.getCarrinho().getTotal();
		//System.out.println("total" +valor);
		bd.processarPagamento(clienteBo, valor);

	bd.desconectar();
	}
	public ClienteBO consultaCliente(int idCliente) {
		
		return bd.selectCliente(idCliente);
	
		}
	public ProdutoBO consultaProduto( int idProduto) {
		
		return bd.selectProduto(idProduto);
}
	public void obterBanco() {
	 bd = new BancoDeDados();
			
	}
	
}

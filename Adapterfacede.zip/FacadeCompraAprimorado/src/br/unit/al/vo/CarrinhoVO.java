package br.unit.al.vo;

public class CarrinhoVO {

}

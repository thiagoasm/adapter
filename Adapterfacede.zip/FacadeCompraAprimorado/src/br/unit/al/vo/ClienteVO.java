package br.unit.al.vo;

public class ClienteVO {

}

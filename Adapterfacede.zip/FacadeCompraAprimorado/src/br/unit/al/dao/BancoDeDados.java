package br.unit.al.dao;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import br.unit.al.bo.ClienteBO;
import br.unit.al.bo.ProdutoBO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;

public class BancoDeDados {

	private Connection connection= null;
	private Statement statement= null;
	private ResultSet resultset=null;
	


	//inicio metodos de conexao
	public void conectar() {
		String servidor= "jdbc:mysql://localhost:3306/carrinho_de_compras";
		String usuario= "root";
		String senha="";
		String driver="com.mysql.jdbc.Driver";
		try {
			Class.forName(driver);
			this.connection= DriverManager.getConnection(servidor, usuario, senha);
			this.statement= this.connection.createStatement();
			
		}catch(Exception e) {
		System.out.println("Erro: "+ e.getMessage());	
		}
		
	}
	public boolean estaConectado() {
		if (this.connection!=null) {
			return true;
		}else {
			return false;
		}
	}
	public void desconectar() {
		try {
			this.connection.close();
		}catch(Exception e) {
			System.out.println("erro: "+ e.getMessage());
		}
		
	}
	// fim metodos de conexao
	
	//inicio metodos de cliente
	public void listarCliente(){
		try {
			String query = "SELECT * FROM cliente ORDER BY id;";

			this.resultset= this.statement.executeQuery(query);
		
		while(this.resultset.next()) {
		
		System.out.println("ID: "+ this.resultset.getString("id") +
				" -nome: " + this.resultset.getString("nome"));

		}
		}
		catch( Exception e) {
			System.out.println("erro: "+ e.getMessage());
			
	}
	}
	public void inserirCliente(String nome, Integer cpfO, String endereco, Integer idO) {
	
	String cpf= Integer.toString(cpfO);
	String id= Integer.toString(idO);
		
	try {
		String query="INSERT INTO cliente (nome,cpf,endereco, id) VALUES ( ' "+ nome+" ',  ' "+ cpf
	  +" ',  ' "+endereco+" ',  ' "+ id+ " ');";
//System.out.println(query);
	this.statement.executeUpdate(query);
		}catch( Exception e) {
			
			System.out.println("erro: "+ e.getMessage());
		}
		}
	public  void apagaCliente(int idO) {
		String id= Integer.toString(idO);
		try {
			String query= "DELETE FROM  cliente WHERE id = "+ id +";";
			this.statement.executeUpdate(query);
		}catch( Exception e) {
			System.out.println("erro: "+ e.getMessage());
			
	}
		
	}
	public ClienteBO selectCliente(int idAux) {
		String id= Integer.toString(idAux); 
	
		try {
			String query = "SELECT * FROM cliente ORDER BY id ;";
			
			this.resultset= this.statement.executeQuery(query);
				
		while(this.resultset.next()) {
		if( id.equals( this.resultset.getString("id"))) {
		System.out.println("id: "+ this.resultset.getString("id") +
				" -nome: " + this.resultset.getString("nome"));
		
		int cpf= Integer.parseInt(this.resultset.getString("cpf"));
		return ClienteBO.create(this.resultset.getString("nome"),
				cpf, this.resultset.getString("endereco"), idAux);
		}
		}
		}
		catch( Exception e) {
			System.out.println("erro: "+ e.getMessage());
			
	}
		return null;
		
	}

//fim metodos de cliente
	
//inicio metodos de produto
	
	public void listarProduto(){
		try {
			String query = "SELECT * FROM lista_de_produtos ORDER BY id;";

			this.resultset= this.statement.executeQuery(query);
		
		while(this.resultset.next()) {
		
		System.out.println("ID: "+ this.resultset.getString("id") +
				" - nome: " + this.resultset.getString("nome"));

		}
		}
		catch( Exception e) {
			System.out.println("erro: "+ e.getMessage());
			
	}
	}
	public void inserirProduto(String id, String nome, float precoAux) {
		String preco= Float.toString(precoAux);
		try {
		String query="INSERT INTO lista_de_produtos (id, nome, preco) VALUES ( ' "+ id+" ',  ' "+ nome
	  +" ',  ' "+preco+ " ');";
//System.out.println(query);
	this.statement.executeUpdate(query);
		}catch( Exception e) {
			
			System.out.println("erro: "+ e.getMessage());
		}
		}
	public  void apagaProduto(int idO) {
		String id= Integer.toString(idO);
		try {
			String query= "DELETE FROM  lista_de_produtos WHERE id = "+ id +";";
			this.statement.executeUpdate(query);
		}catch( Exception e) {
			System.out.println("erro: "+ e.getMessage());
			
	}
		
	}
	public ProdutoBO selectProduto(int idO) {
		String id= Integer.toString(idO); 
		try {
			String query = "SELECT * FROM lista_de_produtos ORDER BY id; ";
			this.resultset= this.statement.executeQuery(query);
			
		while(this.resultset.next()) {
		if( id.equals( this.resultset.getString("id"))) {
		System.out.println("id: "+ this.resultset.getString("id") +
				" - nome " + this.resultset.getString("nome"));
		
		float  preco= Float.parseFloat(this.resultset.getString("preco"));
		
		return ProdutoBO.create( idO,this.resultset.getString("nome"), preco);
		}
		}
		}
		catch( Exception e) {
			System.out.println("erro: "+ e.getMessage());
			
	}
		return null;
	}

	//fim  metodos de produto

	public void processarPagamento(ClienteBO c, double valor) {
		
System.out.println("cliente: "+ c.getId()+"  valor: "+ valor);
	}
	
}
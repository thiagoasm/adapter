package br.unit.al.bo;

public class ProdutoBO {
	private static Integer id;
	private static String nome;
	private static double preco;

	
	
	public ProdutoBO (Integer id, String nome, double preco) {
		
		this.id = id;
		this.nome = nome;
		this.preco = preco;
	}

	public double getPreco() {
		return preco;
	}
	public static ProdutoBO create(Integer id, String nome, double preco) {
		ProdutoBO p = new ProdutoBO(id, nome, preco);
		return p;
	}

	public static Integer getId() {
		return id;
	}

	
}

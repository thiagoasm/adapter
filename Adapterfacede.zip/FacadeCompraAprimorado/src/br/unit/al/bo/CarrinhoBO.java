package br.unit.al.bo;
import java.util.ArrayList;
import java.util.HashMap;

public class CarrinhoBO {
	 HashMap<Integer, ProdutoBO> listaDeProdutos= new  HashMap<Integer, ProdutoBO>();
	
	 public CarrinhoBO(HashMap<Integer, ProdutoBO> listaDeProdutos) {
			super();
			this.listaDeProdutos = listaDeProdutos;
		}
public void adicionar(ProdutoBO p) {

	listaDeProdutos.put(p.getId(), p);	
}

public double getTotal() {
	double total=0;

	for (int i = 0; i <= listaDeProdutos.size(); i++) {
	
		if(listaDeProdutos.get(i)!= null) {
			
			//System.out.println("lista de produtos"+listaDeProdutos.get(i).getId());

			total=total+listaDeProdutos.get(i).getPreco();
;
		}
	}

	return total;
	}
public static CarrinhoBO create(){
	 HashMap<Integer, ProdutoBO> produtos= new HashMap<>();
	 
	CarrinhoBO c= new CarrinhoBO(produtos);
	return c;
	
}
public HashMap<Integer, ProdutoBO> getListaDeProdutos() {
	return listaDeProdutos;
}




}

package br.unit.al.bo;

import java.util.ArrayList;

public class ClienteBO {
	private  String nome;
	private Integer Cpf;
	private String endereco;
	private CarrinhoBO carrinho;
	private  Integer id;


public ClienteBO(String nome, Integer cpf, String endereco, Integer id) {
		super();
		this.nome = nome;
		Cpf = cpf;
		this.endereco = endereco;
		this.id = id;
	}


public static ClienteBO  create(String nome, int cpf, String endereco, int id) {
	ClienteBO c= new ClienteBO(nome,cpf,endereco, id);
	return c;
}

	
	public void adicionarCarinho (CarrinhoBO carrinho) {
		this.carrinho = carrinho;
	}

public CarrinhoBO  getCarrinho() {
	return  carrinho;
}

public int getId() {
	return id;
}


}


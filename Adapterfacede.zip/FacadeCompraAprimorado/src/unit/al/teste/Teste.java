package unit.al.teste;

import br.unit.al.facede.Facede;

public class Teste {
public static void main(String[] args) {
	Facede facede = new Facede();
	facede.obterBanco();
	facede.registrarCliente("soma", 123, "endereco", 12);
	System.out.println("registrou cliente");
	facede.consultaProduto(1);
	System.out.println("consultou produto");
	facede.comprar(12,1);
	facede.fecharCompra(12);
	
System.out.println("end");
	

}
}
